'''
Created on 2021年7月6日

@author: Hsiao-Chien Tsai(蔡効謙)
'''
import azure.cognitiveservices.speech as speechsdk

import time
import tkinter as tk
from tkinter import *
from tkinter.ttk import *

# Creates an instance of a speech config with specified subscription key and service region.
# Replace with your own subscription key and service region (e.g., "westus").
'''
southeastasia
https://southeastasia.api.cognitive.microsoft.com/sts/v1.0/issuetoken
8511f226b8564840b20b01c679e9abdb
caf255542e0042029755680688398cd5
'''
#get microphone
import pyaudio
p = pyaudio.PyAudio()
info = p.get_host_api_info_by_index(0)
numdevices = info.get('deviceCount')
print ("mic count:{}".format(numdevices))
for i in range(0, numdevices):
    #if (p.get_device_info_by_host_api_device_index(0, i).get('maxInputChannels')) > 0:
    #print ("Input Device id {} - {}".format(i, p.get_device_info_by_host_api_device_index(0, i)))
    print ("Input Device id {} - {}".format(i, p.get_device_info_by_index(i)))
    #print(p.get_default_input_device_info())

speech_key, service_region = "6d58f28711be4c0b90bdf767c52d2192", "eastasia"
speech_config = speechsdk.SpeechConfig(subscription=speech_key, region=service_region)
speech_config.speech_recognition_language="zh-TW"
#如何取得device id???
#dev_id = "{0.0.1.00000000}.{e8482d35-d004-4a12-a0c6-e6bfd4ccdde0}"
dev_id = "{0.0.1.00000000}.{334442c6-9b5a-4401-884d-05efad161398}"
audio_config = speechsdk.AudioConfig(device_name=dev_id)
# Creates a recognizer with the given settings
speech_recognizer = speechsdk.SpeechRecognizer(speech_config=speech_config, audio_config=audio_config)



def from_mic():
    speech_config = speechsdk.SpeechConfig(subscription=speech_key, region=service_region)
    speech_config.speech_recognition_language="zh-TW"
    speech_recognizer = speechsdk.SpeechRecognizer(speech_config=speech_config)
    
    print("Speak into your microphone.")
    result = speech_recognizer.recognize_once_async().get()
    print(result.text)

from_mic()



class Test():
    def __init__(self):
        self.root = tk.Tk()
        self.label = tk.Label(self.root, text="Text")

        self.button = tk.Button(self.root,
                                text="Click to change text below",
                                command=self.changeText(""))
        self.button.pack()
        self.label.pack()
        self.root.mainloop()

    def changeText(self, text):
        self.label['text'] = text


print ("開始錄製")
done = False
def stop_cb(evt):
    global done
    print('CLOSING on {}'.format(evt))
    speech_recognizer.stop_continuous_recognition()    
    done = True
def recog_process(evt):
    print('RECOGNIZED: {}'.format(evt))
    print(evt.result.text)
    app.changeText(evt.result.text)
    
    
if __name__ == "__main__" :     
    speech_recognizer.recognized.connect(recog_process)
    speech_recognizer.session_stopped.connect(stop_cb)
    speech_recognizer.canceled.connect(stop_cb)
    speech_recognizer.start_continuous_recognition()



    app=Test()

    while not done:
        time.sleep(.5)
        speech_recognizer.stop_continuous_recognition()
        speech_recognizer.session_started.disconnect_all()
        speech_recognizer.recognized.disconnect_all()
        speech_recognizer.session_stopped.disconnect_all()
