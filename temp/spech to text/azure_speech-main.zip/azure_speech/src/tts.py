'''
Created on 2021年7月6日

@author: Hsiao-Chien Tsai(蔡効謙)
'''
# Copyright (c) Microsoft. All rights reserved.
# Licensed under the MIT license. See LICENSE.md file in the project root for full license information.

# <code>
import azure.cognitiveservices.speech as speechsdk
import time

def get_voice_names():
    file_name = "voice_data/voice_name_list.txt" 
    res = []
    with open(file_name,"r",encoding="utf-8") as f:
        lines = f.readlines()
        for l in lines :
            if not l.startswith("#") :
                name = l.strip()
                res.append(name)
    return res
# Creates an instance of a speech config with specified subscription key and service region.
# Replace with your own subscription key and service region (e.g., "westus").
speech_key, service_region = "6d58f28711be4c0b90bdf767c52d2192", "eastasia"
speech_config = speechsdk.SpeechConfig(subscription=speech_key, region=service_region)
#https://docs.microsoft.com/zh-tw/azure/cognitive-services/speech-service/language-support#neural-voices
speech_config.speech_synthesis_voice_name="zh-CN-XiaoyouNeural"
#zh-TW-HsiaoChenNeural
speech_config.speech_synthesis_voice_name="zh-CN-YunyeNeural"
# Creates a speech synthesizer using the default speaker as audio output.
#audio_config = speechsdk.AudioOutputConfig(filename="file.wav")
#audio_config = speechsdk.AudioOutputConfig(use_default_speaker=True)
speech_synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config)

# Receives a text from console input.
print("Type some text that you want to speak...")
#text = input()
query_text  = "上1頁"
query_list = ["好的"]
# Synthesizes the received text to speech.
# The synthesized speech is expected to be heard on the speaker with this line executed.
voice_names = ["zh-CN-XiaoyouNeural","zh-CN-YunyeNeural","zh-TW-HsiaoChenNeural"]
voice_names = get_voice_names()
for q in query_list :
    query_text = q
    for v in voice_names :
        speech_config.speech_synthesis_voice_name=v
        speech_synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config)
        result = speech_synthesizer.speak_text_async(query_text).get()
        # Checks result.
        if result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted :
            stream = speechsdk.AudioDataStream(result)
            file_name = "data/tts/file_{}_{}_{}.wav".format(v,query_text,time.strftime("%Y%m%d-%H%M%S"))
            stream.save_to_wav_file(file_name)
            print("Speech synthesized to speaker for text [{}] - {} ".format(query_text, v))
        else :
            print ("{}-{}".format(v,q))
            print (result.reason)
             
