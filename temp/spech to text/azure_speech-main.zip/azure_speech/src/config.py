'''
Created on 2021年7月8日

@author: Hsiao-Chien Tsai(蔡効謙)
'''
"""

"""

speech_key = "<Your speech API key here>"
service_region = "<Your speech region>"
#default uuid
device_uuid =""
#office usb microphone
#device_uuid ="{0.0.1.00000000}.{5358a413-499b-4712-b9f8-c08033b8445d}"
#notebook usb microphone
#device_uuid ="{0.0.1.00000000}.{b6fd2316-8e07-40b4-a42c-ed8c5ae29286}" #usb
speech_key, speech_service_region = "xxxxx", "eastasia"
trans_key, trans_service_region = "xxxxx", "eastasia"
translation_enable = False