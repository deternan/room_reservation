'''
Created on 2022年3月28日

@author: Hsiao-Chien Tsai
'''
import requests, uuid, json
import config
# Add your key and endpoint
key = config.trans_key
endpoint = "https://api.cognitive.microsofttranslator.com/"

# Add your location, also known as region. The default is global.
# This is required if using a Cognitive Services resource.
location = config.trans_service_region

path = '/translate'
constructed_url = endpoint + path

params = {
    'api-version': '3.0',
    'from': 'zh-Hant',
    'to': ['en']
}

headers = {
    'Ocp-Apim-Subscription-Key': key,
    'Ocp-Apim-Subscription-Region': location,
    'Content-type': 'application/json',
    'X-ClientTraceId': str(uuid.uuid4())
}

# You can pass more than one object in body.


def chi_en(chi_text):
    body = [{
    'text': chi_text
    }]
    request = requests.post(constructed_url, params=params, headers=headers, json=body)
    response = request.json()
    
    #print(json.dumps(response, sort_keys=True, ensure_ascii=False, indent=4, separators=(',', ': ')))
    return(response[0]["translations"][0]["text"])
if __name__ == "__main__" :
    print(chi_en("測試英文翻譯"))