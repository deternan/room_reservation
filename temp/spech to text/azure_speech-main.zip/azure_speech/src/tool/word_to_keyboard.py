'''
Created on 2021年11月15日

@author: User
'''
import keyboard
from tool import filetools
from tool import utils
from tool import language_model
# 1.設定

# keywords 轉 鍵盤動作
keyword_config_path = "data/keywords/keyword_action.txt"
keyword_keyborad = filetools.file_to_list(keyword_config_path)
# gesture names to keyboard keys dictionary
# 須注意一個keyword 可能對應多個 keyboard keys
keyword_to_keyboard = {gk[0]:gk[1] for gk in keyword_keyborad}
keyword_to_desc = {gk[0]:gk[2] for gk in keyword_keyborad}
print (keyword_to_keyboard)
# 2.不斷接收語音
# 3.語音轉文字
# 4.文字比對
# 5.文字轉動作 

def keywords_to_desc(keywords):
    #print ("偵測到 keywords事件:{}".format(keywords))    
    keyboard_list = []
    for k in keywords  :
        if k in keyword_to_desc  :
            keyboard_list.append(keyword_to_desc[k]) 
    #去除重複的事件
    return list(set(keyboard_list))

def keywords_to_keyboard(keywords):
    #print ("偵測到 keywords事件:{}".format(keywords))    
    keyboard_list = []
    for k in keywords  :
        #須注意擴展性 - 一個 keyword 可能對應多個 keyboard keys
        if k in keyword_to_keyboard  :
            keyboard_list.append(keyword_to_keyboard[k]) 
    #去除重複的事件
    return list(set(keyboard_list))


def keywords_to_action(kws):
    correct_kws = language_model.speech_text_correction(kws)
    kb_command = keywords_to_keyboard(correct_kws)
    if (len(kb_command)>0) :
        print (kb_command)
    for c in kb_command :
        keyboard.press_and_release(c)
        print (c)