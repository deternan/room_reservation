'''
Created on 2021年11月12日

@author: Hsiao-Chien Tsai(蔡効謙)
'''
import os 
from tool import filetools

#configuration 
keyword_correction_path = "data/keywords"
#
def generate_correciton_table():
    """步驟
    1.讀取多個文件名稱與內容
    2.建立一個　dictionary {內容－－－＞名稱}
    """
    file_names = os.listdir(keyword_correction_path)
    correct_table = {}
    for file_name in file_names :
        keyword = os.path.splitext(file_name)[0]
        word_list = filetools.file_to_list(keyword_correction_path + os.sep + file_name)
        
        # Merge two dictionary
        new_dict = {w[0]:keyword for w in word_list}
        correct_table = {**correct_table, **new_dict} 
        
    return correct_table
