'''
Created on 2021年11月22日

@author: User
'''
def word_rmm_ner_tagging(sentence, ner_dict, max_len = 22):    
    # RMM (Reverse Maximum Matching)，找特定類型的詞
    tag_wordlist = {} # 用來記錄 [tag-->[words]]   
    #長詞優先匹配
    word_len = len(sentence) 
    mask = [0] * len(sentence)
    #性能問題，只識別特定長度的詞
    if (word_len > max_len) :
        word_len = max_len
    #逐漸縮小詞的長度        
    while word_len > 0 :
        idx = len(sentence) # 從右側開始比對
        while idx - word_len >= 0 :
            current_word =  sentence[idx-word_len:idx]
            #print (current_word)
            #避免嵌套標註          
            embeded = False           
            for m in mask [idx-word_len:idx]  :
                if m != 0 : # 已經被標註了
                    embeded = True
            if (embeded) :
                idx -= 1 
                continue            
            # 判斷詞是否有特定意義
            if current_word.lower() in ner_dict :
                tag_type = ner_dict[current_word.lower()]
                if tag_type in tag_wordlist : 
                    tag_wordlist[tag_type] =  tag_wordlist[tag_type] + [current_word]
                else :
                    tag_wordlist[tag_type] = [current_word]
                #
                mask[idx-word_len:idx] = list(current_word)
                #print (list(current_word),mask)
                idx -= word_len
            else :
                idx -= 1 
        word_len -= 1
    #去重複        
    for k, v in tag_wordlist.items() :
        tag_wordlist[k] =   list(set(v)) 
    
    return tag_wordlist

def recognize_keywords(sentence, ner_dict, max_len = 22):    
    tag_words = word_rmm_ner_tagging(sentence, ner_dict, max_len = 22)
    return list(tag_words.keys())

def rewrite_keywords(sentence, ner_dict, max_len = 22):    
    tag_words = word_rmm_ner_tagging(sentence, ner_dict, max_len = 22)
    for tag,words in tag_words.items() :
        for w in words :
            sentence = sentence.replace(w,tag)
    return sentence 
        
    