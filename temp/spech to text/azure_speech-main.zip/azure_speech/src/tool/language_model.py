'''
Created on 2021年11月15日

@author: User
'''
import keyboard
from tool import filetools
from tool import utils
# 1.設定

correct_table = utils.generate_correciton_table()
def speech_text_correction(text_list):
    """This function 
    Args:
       name (str):  The name to use.
    Returns:
    return 
    """
    res = []
    for text in text_list :
        if text in correct_table :
            text = correct_table[text]
        res.append(text)
    return res     

