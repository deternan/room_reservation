'''
Created on 2021年7月8日

@author: Hsiao-Chien Tsai(蔡効謙)
'''
import config
import time
import azure.cognitiveservices.speech as speechsdk
from tkinter import *
import tkinter as tk
import translate
#kws
from tool import nlptools
from tool.language_model import correct_table
from tool import language_model
from tool import word_to_keyboard
#
from queue import Queue
import re 
translation = config.translation_enable
kws_enable = True
display_mode = "normal"
timestr = ""
timestr = time.strftime("%Y%m%d-%H%M%S")
record_path="data/records/"
record_file="captions_" + timestr + ".txt"
f = open(record_path + record_file, 'a', buffering=1, encoding="utf-8")

#tkinter 設定
appHeight = 250
label_padding = 2
labelText = NONE
root = Tk()
labelText = StringVar()
strokeText = StringVar()
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
#字幕是否要留邊
screen_buttom_padding = 10
screen_left_right_padding = 10
left_padding = 2
#寬，高，left_padding buttom_padding
#geo_str = str(screen_width-left_padding*2) + "x" + str(appHeight) + "+"+ str(left_padding) +"+" + str(screen_height - appHeight -40)
geo_str = str(int(screen_width*0.25)) + "x" + str(appHeight) + "+"+ str(left_padding) +"+" + str(screen_height - appHeight -40)
print (geo_str)
root.geometry(geo_str)
root.configure(background='white')
root.update_idletasks()
# 不顯示邊框，不能移動
window_border = True 
if not window_border :
    root.overrideredirect(True)

root.title("")
#透明度
root.attributes('-alpha', 0.75)
labelWidth = screen_width-(label_padding * 2)
label = Label(root, textvariable=labelText, 
              foreground="white", height=appHeight, width=labelWidth, 
              #foreground="white", height=appHeight, width=labelWidth, 
              #background='black', font=("Courier", 40),
              background='black', font=("微軟正黑體 14 bold "),
              
              justify=LEFT, anchor=SW, wraplength=labelWidth)
label.pack(padx=label_padding, pady=label_padding)
root.attributes('-topmost', True)
root.wm_attributes('-transparentcolor','blue')

subtitle_queue = Queue(maxsize = 10)

# Speech 
def recognizing(args):
    global labelText
    labelText.set("\n".join(list(subtitle_queue.queue) +[args.result.text]))
    #labelText.set(args.result.text)

def recognized(args):
    global f, subtitle_queue
    if args.result.text.strip() != '':
        output_text = args.result.text
        # kws 
        
        if kws_enable :
            kws = nlptools.recognize_keywords(args.result.text,correct_table)
            correct_kws = language_model.speech_text_correction(kws)
            if (len(kws) > 0) :
                word_to_keyboard.keywords_to_action(kws)
                #desc = word_to_keyboard.keywords_to_desc(kws)
            #print ("correct:{}".format(correct_kws))   
                correct_text = nlptools.rewrite_keywords(output_text,correct_table)
                print("{}-->{}".format(output_text,correct_text))
                output_text = correct_text 
                
            
       
        if translation :
            trans = translate.chi_en(output_text)
            if ( re.sub(r"[，。？]", "", trans) != output_text) :
                output_text = output_text + translate.chi_en(output_text)
        
        #顯示字幕，將句子分行        
        sentence_seg = re.split(r"[，。？]", output_text);
        for s in sentence_seg:
            if (len(s)>0) :
                if subtitle_queue.full() :
                    subtitle_queue.get()
                subtitle_queue.put(s)
            
        #labelText.set(output_text)
        labelText.set("\n".join(list(subtitle_queue.queue)))
        print (output_text)
        f.write(output_text + "\n")
        
        
        
if __name__ == "__main__" :    
    speech_config = speechsdk.SpeechConfig(subscription=config.speech_key, region=config.speech_service_region)
    speech_config.speech_recognition_language="zh-TW"
    speech_recognizer = speechsdk.SpeechRecognizer(speech_config=speech_config)
    if config.device_uuid != "":
        #https://docs.microsoft.com/zh-tw/azure/cognitive-services/speech-service/howpyt-to-select-audio-input-devices
        try:
            print (config.device_uuid)
            audio_config = speechsdk.AudioConfig(device_name=config.device_uuid);
            speech_recognizer = speechsdk.SpeechRecognizer(speech_config=speech_config, audio_config=audio_config)
        except : 
            print ("Device id error:{}\nUsing default MIC.".format(config.device_uuid))
            
            
    
    speech_recognizer.recognizing.connect(recognizing)
    speech_recognizer.recognized.connect(recognized)
    speech_recognizer.start_continuous_recognition()
    
    labelText.set("...")    
    
    root.mainloop()
    root.destroy()
    speech_recognizer.stop_continuous_recognition()
    speech_recognizer.session_started.disconnect_all()
    speech_recognizer.recognized.disconnect_all()
    speech_recognizer.session_stopped.disconnect_all()